print("===================")
print("DNA ANALYZER TOOL")
print("===================")
DNA=input("enter your sequence:")
DNA=DNA.upper()
print("your sequence:   ", DNA)
length=len(DNA)
print("your dna length: ",length)
A_count=DNA.count("A")
T_count=DNA.count("T")
C_count=DNA.count("C")
G_count=DNA.count("G")
print("A:             ",A_count)
print("T:             ",T_count)
print("C:             ",C_count)
print("G:             ",G_count)
GC=G_count+C_count
GC_percent=(GC/length)*100
print("GC CONTENT:     ",round(GC_percent,2),"%")
AT=A_count+T_count
AT_percent=(AT/length)*100
print("AT CONTENT:     ",round(AT_percent,2),"%")
valid=True
for base in DNA:
    if base not in "ATCG":
        valid=False
        break


if valid:
    print("STATUS:        DNA SEQUENCE IS VALID:")
else: 
    print("STATUS:        DNA SQUENCE IS NOT VALID:")
