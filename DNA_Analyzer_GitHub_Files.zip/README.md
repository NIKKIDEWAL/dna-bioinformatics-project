# DNA Analyzer Tool Using Python

## Overview
This beginner Python project accepts a DNA sequence and reports its length, the count of A, T, C, and G bases, GC content, AT content, and whether the sequence contains only A, T, C, and G.

## How to Run
1. Install Python 3 if it is not already installed.
2. Open a terminal or command prompt in the folder containing `dna.py`.
3. Run:
   ```bash
   python dna.py
   ```
   On some systems, use `python3 dna.py`.
4. Enter a DNA sequence when prompted, for example `ATGCCGTA`.

## Formulas
- GC count = G count + C count
- GC content (%) = (GC count / DNA length) × 100
- AT count = A count + T count
- AT content (%) = (AT count / DNA length) × 100

## Project Files
- `dna.py` — Python source code
- `Project_Report.docx` — written project report

## Note
Enter a non-empty DNA sequence made from A, T, C, and G for a valid example. The current script checks validity, but it calculates percentages before the validity check; empty input can cause a division-by-zero error.
